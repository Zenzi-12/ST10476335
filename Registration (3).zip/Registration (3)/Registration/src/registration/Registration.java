package registration;

import javax.swing.JOptionPane;

public class Registration {
    private static String firstName;
    private static String lastName;
    private static String password;
    private static String username;
    private static String phoneNumber;

    // set the user's first name
    public static void setFirstName(String name) { firstName = name; }
    public static String getFirstName() { return firstName; }
    //get the user's first name

    public static void setLastName(String surname) { lastName = surname; }
    public static String getLastName() { return lastName; }
    //set the user's lastname

    public static void setUserName(String userName) { username = userName; }
    public static String getUserName() { return username; }
    //get the user's name

    public static void setPassword(String pass) { password = pass; }
    public static String getPassword() { return password; }
    //set the password

    public static void setPhoneNumber(String phone) { phoneNumber = phone; }
    public static String getPhoneNumber() { return phoneNumber; }
    //set the phone number

    
    public static void main(String[] args) {
        //prompt the user to enter their first name
        setFirstName(JOptionPane.showInputDialog(null, "Please enter your first name:"));
        //prompt the user to enter their last name
        setLastName(JOptionPane.showInputDialog(null, "Please enter your last name:"));

        // Username input
        String usernameInput;
        do {
            //prompt the user to enter their username
            usernameInput = JOptionPane.showInputDialog(null, "Enter username (≤5 chars and must contain '_'):");
            //check the username meets the conditions
            if (!Login.checkUserName(usernameInput)) {
                JOptionPane.showMessageDialog(null,
                        "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
            }
            //keep on asking until the username is correct
        } while (!Login.checkUserName(usernameInput));
        setUserName(usernameInput);

        // Password input
        String passwordInput;
        do {
            passwordInput = JOptionPane.showInputDialog(null,
                    "Enter password (≥8 chars, must include: 1 capital, 1 number, 1 special character):");
            //check if the password meets the correct conditio
            if (!Login.checkPasswordComplexity(passwordInput)) {
                JOptionPane.showMessageDialog(null,
                        "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        } while (!Login.checkPasswordComplexity(passwordInput));
        setPassword(passwordInput);

        // Phone number input
        String phoneInput;
        do {
            //prompt the user to enter their phone number
            phoneInput = JOptionPane.showInputDialog(null,
                    "Enter phone number (must start with +27 followed by 9 digits):\nExample: +27831234567");
            if (!Login.checkCellPhoneNumber(phoneInput)) {
                //check if the cell phone number meets the correct conditions
                JOptionPane.showMessageDialog(null,
                        "Cell phone number incorrectly formatted or does not contain international code.");
            }
        } while (!Login.checkCellPhoneNumber(phoneInput));
        setPhoneNumber(phoneInput);

        // Register User
        Login login = new Login();
        //registering the user with their details
        String registrationResult = login.registerUser(getUserName(), getPassword(), getPhoneNumber());
        //show the registration results
        JOptionPane.showMessageDialog(null, registrationResult);

        // LOGIN PROCESS 
        boolean loginSuccessful = false;
        int attempts = 0;
        final int MAX_ATTEMPTS = 3;

        while (!loginSuccessful && attempts < MAX_ATTEMPTS) {
            //ask the user to enter their username
            String enteredUsername = JOptionPane.showInputDialog("Enter username to login:");
            //ask the user to enter to their password
            String enteredPassword = JOptionPane.showInputDialog("Enter password to login:");
            
            //save the entered username and password

            login.setEnteredUsername(enteredUsername);
            login.setEnteredPassword(enteredPassword);
            
            //check if login is successful
            if (login.loginUser()) {
                //if login is a success show success message
                JOptionPane.showMessageDialog(null, login.returnLoginStatus());
                loginSuccessful = true;
            } else {
                //if wrong increase attempt count
                attempts++;
                //shoe error message with number of attempts used
                JOptionPane.showMessageDialog(null,
                        "Login failed. Attempt " + attempts + " of " + MAX_ATTEMPTS
                                + "\nUsername or password incorrect, please try again.");
            }
        }
         //if the user fails all atempts show final error message
        if (!loginSuccessful) {
            JOptionPane.showMessageDialog(null, "Maximum login attempts exceeded. Please try again later.");
        }
    }
}
